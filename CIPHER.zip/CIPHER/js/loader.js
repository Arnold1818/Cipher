var myVar;

function loader() {
    myVar = setTimeout(showPage, 3000);
}

function showPage() {
    document.getElementById("cipher").style.display = "none";
    document.getElementById("myDiv").style.display = "block";
}